# 3EA Token List (Uniswap/Tokenlists)

This repository hosts a Token List JSON for the 3rdeyeadvisors token (3EA) on **Base Mainnet (chainId 8453)**.

## How to use

1. Open `3ea-tokenlist.json` and replace:
   - `REPLACE_WITH_3EA_CONTRACT_ADDRESS` with your **Base** token contract address.
   - Optionally uncomment and set `logoURI` to a **public PNG URL** (256x256, transparent background) when ready.

2. Commit to a **public GitHub repo**. Copy the **Raw** URL of the JSON file (must be HTTPS).

3. Test in Uniswap:
   - Go to `app.uniswap.org` → Settings (gear icon) → **Token Lists** → **Add List** → paste the Raw URL.

4. Submit to Tokenlists.org (optional but recommended):
   - Open https://tokenlists.org → **Add List** and paste the Raw URL.
   - You can also open an issue in https://github.com/Uniswap/tokenlists-org with your list URL for broader discovery.

5. Update later with logo:
   - Set `logoURI` to your hosted PNG once graphics are ready.

## Notes
- Schema: https://github.com/Uniswap/token-lists
- Base chainId = **8453**.
